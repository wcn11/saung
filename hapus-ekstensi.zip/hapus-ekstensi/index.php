<!DOCTYPE HTML>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <title>Menghapus ekstensi .php .html dengan file .htaccess - Codingan.com</title>

        <link rel="stylesheet" href="style.css" type="text/css" />

    </head>
<body>

<center>

<div id="menu">
<ul>
	<li><a href="index">home</a></li>
    <li><a href="login">login</a></li>
    <li><a href="daftar">daftar</a></li>
    <li><a href="about">about</a></li>
</ul>
</div>

<div id="body">

<h1>Ini adalah halaman index.php | lihat url di addressbar</h1> <br />

<a href="http://codingan.com/menghapus-ekstensi-php-html-dengan-htaccess/">Tutorial</a>

</div>
</center>

</body>
</html>
